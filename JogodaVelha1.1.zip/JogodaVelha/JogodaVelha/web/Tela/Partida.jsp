<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="Jogo.Regras" %>
<%
Regras regra = new Regras();
char[][] Val = new char[3][3];

for(int i = 0; i < 3; i++){
    for(int j = 0; j < 3; j++){
        Val[i][j] = regra.getTabuleiro(i, j);
    }
}



%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jogo da Velha</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <header>
        <div class="escrita-jogo-da-velha">
            <h1 class="">Jogo da Velha</h1>
        </div>
        <div class="placar" id="placar-jogo">
            <h2>Vez do jogador</h2>
        </div>
    </header>

    <main>
        <section>

            <div class="tabuleiro">
                <div value="<%= Val[0][0] %>" class="celula"></div>
                <div value="<%= Val[0][1] %>" class="celula"></div>
                <div value="<%= Val[0][2] %>" class="celula"></div>

                <div value="<%= Val[1][0] %>" class="celula"></div>
                <div value="<%= Val[1][1] %>" class="celula"></div>
                <div value="<%= Val[1][2] %>" class="celula"></div>

                <div value="<%= Val[2][0] %>" class="celula"></div>
                <div value="<%= Val[2][1] %>" class="celula"></div>
                <div value="<%= Val[2][2] %>" class="celula"></div>
            </div>

        </section>
    </main>

    <footer>

    </footer>

</body>

</html>
</html>
