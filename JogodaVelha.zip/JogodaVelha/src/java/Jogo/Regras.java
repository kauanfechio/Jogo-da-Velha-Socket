/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Jogo;

/**
 *
 * @author Aluno
 */
public class Regras {
    
    private char jogada;
    private char vez = 'O';
    private char tabuleiro[][] = {{'1', '2', '3'}, {'4', '5', '6'}, {'7', '8', '9'}};
    private int quadrante;
    private int turnos = 0;
    private boolean vitoria = false;
    

    public char getJogada() {
        return jogada;
    }

    public void setJogada(char jogada) {
        this.jogada = jogada;
    }

    public char getVez() {
        return vez;
    }

    public void setVez(char vez) {
        this.vez = vez;
    }

    public char[][] getTabuleiro() {
        return tabuleiro;
    }

    public void setTabuleiro(char[][] tabuleiro) {
        this.tabuleiro = tabuleiro;
    }

    public int getQuadrante() {
        return quadrante;
    }

    public void setQuadrante(int quadrante) {
        this.quadrante = quadrante;
    }

    public int getTurnos() {
        return turnos;
    }

    public void setTurnos(int turnos) {
        this.turnos = turnos;
    }

    public boolean isVitoria() {
        return vitoria;
    }

    public void setVitoria(boolean vitoria) {
        this.vitoria = vitoria;
    }
        
    public void play(){
        int a = 0;	
			for(int i = 0; i < 3; i++) {
				for(int j = 0; j < 3; j++) {
					a++;
					if(a == jogada) {
						tabuleiro[i][j] = vez;
					}
				}
			}
        
    }
    
    public void testaVitoria(){
        for(int i = 0; i < 3; i++) {
				if(tabuleiro[1][1] == tabuleiro[0][0+i] && tabuleiro[1][1] == tabuleiro[2][2-i]) {
					vitoria = true;
				}else if(tabuleiro[i][0] == tabuleiro[i][1] && tabuleiro[i][0] == tabuleiro[i][2]) {
					vitoria = true;
				}else if(tabuleiro[0][i] == tabuleiro[1][i] && tabuleiro[0][i] == tabuleiro[2][i]) {
					vitoria = true;
				}
			}
    }
}
