<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="Jogo.Regras"%>
<%
Regras regra = new Regras();
if(regra.getVez() == 'O'){
    regra.setVez('X');
    }else{
    regra.setVez('O');
}





%>


<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tabuleiro Jogo da Velha</title>

  <style>
    body {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
      background-color: #f2f2f2;
    }

    .tabuleiro {
      display: grid;
      grid-template-columns: repeat(3, 120px);
      grid-template-rows: repeat(3, 120px);
      gap: 5px;
    }

    .quadrado {
      width: 120px;
      height: 120px;
      background-color: white;
      border: 3px solid #333;
    }
  </style>
</head>

<body>

  <div class="tabuleiro">
    <div class="quadrado"></div>
    <div class="quadrado"></div>
    <div class="quadrado"></div>

    <div class="quadrado"></div>
    <div class="quadrado"></div>
    <div class="quadrado"></div>

    <div class="quadrado"></div>
    <div class="quadrado"></div>
    <div class="quadrado"></div>
  </div>

</body>
</html>
