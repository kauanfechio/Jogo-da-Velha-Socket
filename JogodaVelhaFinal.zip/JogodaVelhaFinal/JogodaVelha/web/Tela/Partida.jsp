<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="Jogo.Regras" %>
<%

Regras regra = (Regras) session.getAttribute("regra");
if (regra == null) {
    regra = new Regras();
    session.setAttribute("regra", regra);
}

boolean valido = false;

// Captura a célula clicada
String p = request.getParameter("cell");
if(p != null){
    if(!p.equals("X") && !p.equals("O")){
        regra.play(p.charAt(0) - '0');
        valido = true;
    }else{
    %>
        <script>
            alert("Essa quadrante ja foi escolhido");
        </script>
    <%
    }
}

char[][] Val = regra.getTabuleiro();

if(regra.testaVitoria()){
        session.removeAttribute("regra");
        session.invalidate();
    %>
        <script>
            alert("Vitoria do <%= regra.getVez()%>");
            window.location.href = "http://localhost:8081/JogodaVelha/";
        </script>
    <%}else if(regra.getTurnos() == 9){
        session.removeAttribute("regra");
        session.invalidate();
%>
        <script>
            alert("Deu Velha!");
            window.location.href = "http://localhost:8081/JogodaVelha/";
        </script>
        <%}else if(valido){
            regra.mudaVez();
        }

%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jogo da Velha</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="stylesheet/style.css">
</head>

<body>
    <header>
        <div class="escrita-jogo-da-velha">
            <h1 class="">Jogo da Velha</h1>
        </div>
        <div class="placar" id="placar-jogo">
            <h2>Vez do jogador <%=regra.getVez()%></h2>
        </div>
    </header>

    <main>
        <section>
                <form method="get" action="" class="tabuleiro">
                    <button value="<%= Val[0][0] %>" name="cell" class="celula" type="submit"></button>
                    <button value="<%= Val[0][1] %>" name="cell" class="celula" type="submit"></button>
                    <button value="<%= Val[0][2] %>" name="cell" class="celula" type="submit"></button>

                    <button value="<%= Val[1][0] %>" name="cell" class="celula" type="submit"></button>
                    <button value="<%= Val[1][1] %>" name="cell" class="celula" type="submit"></button>
                    <button value="<%= Val[1][2] %>" name="cell" class="celula" type="submit"></button>

                    <button value="<%= Val[2][0] %>" name="cell" class="celula" type="submit"></button>
                    <button value="<%= Val[2][1] %>" name="cell" class="celula" type="submit"></button>
                    <button value="<%= Val[2][2] %>" name="cell" class="celula" type="submit"></button>
                </form>
        </section>
    </main>

    <footer>

    </footer>

</body>

</html>
</html>
