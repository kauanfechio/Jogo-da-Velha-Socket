/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Jogo;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class ServidorJogo {
    private static final int PORTA = 8081;
    private static Regras regras = new Regras();
    private static PrintWriter[] outputs = new PrintWriter[2]; // [0] = X, [1] = O
    private static int jogadoresConectados = 0;

    public static void main(String[] args) {
        try (ServerSocket servidor = new ServerSocket(PORTA)) {
            System.out.println("Servidor do Jogo da Velha iniciado na porta " + PORTA);
            System.out.println("Aguardando jogadores...");

            while (jogadoresConectados < 2) {
                Socket socket = servidor.accept();
                char simbolo = (jogadoresConectados == 0) ? 'X' : 'O';
                System.out.println("Jogador " + simbolo + " conectado de: " + socket.getRemoteSocketAddress());

                outputs[jogadoresConectados] = new PrintWriter(socket.getOutputStream(), true);
                
                // Dispara uma thread para cuidar da comunicação com este cliente específico
                Thread t = new Thread(new ManipuladorCliente(socket, simbolo, jogadoresConectados));
                t.start();

                jogadoresConectados++;
            }

            // Avisa ambos os jogadores que a partida vai começar
            enviarParaAmbos("START");
            notificarTurno();

        } catch (Exception e) {
            System.out.println("Erro no servidor: " + e.getMessage());
        }
    }

    private static synchronized void processarJogada(int jogada, char simbolo) {
        // 1. Validar se é a vez do jogador correto
        if (regras.getVez() != simbolo) {
            enviarParaJogador(simbolo, "ERROR;Não é a sua vez!");
            return;
        }

        // 2. Mapear o número da jogada (1-9) para verificar se a célula está ocupada
        int a = 0;
        boolean ocupado = true;
        char[][] tab = regras.getTabuleiro();
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                a++;
                if (a == jogada) {
                    if (tab[i][j] != 'X' && tab[i][j] != 'O') {
                        ocupado = false;
                    }
                }
            }
        }

        if (ocupado) {
            enviarParaJogador(simbolo, "ERROR;Esse quadrante já foi escolhido!");
            return;
        }

        // 3. Executar a jogada
        regras.play(jogada);
        
        // Envia o tabuleiro atualizado para ambos no formato: BOARD;v1,v2,v3,v4...
        enviarTabuleiroAtualizado();

        // 4. Verificar condições de fim de jogo
        if (regras.testaVitoria()) {
            enviarParaAmbos("OVER;WIN;" + simbolo);
            return;
        } else if (regras.getTurnos() == 9) {
            enviarParaAmbos("OVER;DRAW");
            return;
        }

        // 5. Passar o turno se o jogo continua
        regras.mudaVez();
        notificarTurno();
    }

    private static void enviarTabuleiroAtualizado() {
        StringBuilder sb = new StringBuilder("BOARD;");
        char[][] tab = regras.getTabuleiro();
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                sb.append(tab[i][j]).append(",");
            }
        }
        // Remove a última vírgula
        sb.setLength(sb.length() - 1);
        enviarParaAmbos(sb.toString());
    }

    private static void notificarTurno() {
        enviarParaAmbos("TURN;" + regras.getVez());
    }

    private static void enviarParaAmbos(String msg) {
        if (outputs[0] != null) outputs[0].println(msg);
        if (outputs[1] != null) outputs[1].println(msg);
    }

    private static void enviarParaJogador(char simbolo, String msg) {
        int idx = (simbolo == 'X') ? 0 : 1;
        if (outputs[idx] != null) outputs[idx].println(msg);
    }

    // Classe interna para rodar em paralelo escutando as mensagens de cada cliente
    private static class ManipuladorCliente implements Runnable {
        private Socket socket;
        private char simbolo;
        private int id;

        public ManipuladorCliente(Socket socket, char simbolo, int id) {
            this.socket = socket;
            this.simbolo = simbolo;
            this.id = id;
            // Avisa o cliente qual é o símbolo dele assim que conecta
            outputs[id].println("WELCOME;" + simbolo);
        }

        @Override
        public void run() {
            try (BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {
                String linha;
                while ((linha = input.readLine()) != null) {
                    // Protocolo esperado do cliente: MOVE;numero
                    if (linha.startsWith("MOVE;")) {
                        if (jogadoresConectados < 2) {
                            outputs[id].println("ERROR;Aguardando segundo jogador...");
                            continue;
                        }
                        int jogada = Integer.parseInt(linha.split(";")[1]);
                        processarJogada(jogada, simbolo);
                    }
                }
            } catch (Exception e) {
                System.out.println("Jogador " + simbolo + " desconectou abruptamente.");
            } finally {
                enviarParaAmbos("OVER;OPPONENT_DISCONNECTED");
            }
        }
    }
}