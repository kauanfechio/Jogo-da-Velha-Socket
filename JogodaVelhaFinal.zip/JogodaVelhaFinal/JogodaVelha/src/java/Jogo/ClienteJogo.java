/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Jogo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class ClienteJogo extends JFrame {
    private JButton[] botoes = new JButton[9];
    private JLabel lblTitulo;
    private JLabel lblPlacar;
    
    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;
    
    private char meuSimbolo;
    private char vezAtual;

    public ClienteJogo() {
        configurarInterface();
        conectarAoServidor();
    }

    private void configurarInterface() {
        setTitle("Jogo da Velha em Rede");
        setSize(400, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Cabeçalho (Baseado no seu HTML)
        JPanel painelSuperior = new JPanel(new GridLayout(2, 1));
        painelSuperior.setBackground(new Color(245, 245, 245));
        
        lblTitulo = new JLabel("Jogo da Velha", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Poppins", Font.BOLD, 24));
        
        lblPlacar = new JLabel("Conectando ao servidor...", SwingConstants.CENTER);
        lblPlacar.setFont(new Font("Poppins", Font.PLAIN, 16));
        
        painelSuperior.add(lblTitulo);
        painelSuperior.add(lblPlacar);
        add(painelSuperior, BorderLayout.NORTH);

        // Tabuleiro (Form/Grid de botões)
        JPanel painelTabuleiro = new JPanel(new GridLayout(3, 3, 5, 5));
        painelTabuleiro.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        for (int i = 0; i < 9; i++) {
            final int posicao = i + 1; // 1 a 9
            botoes[i] = new JButton("");
            botoes[i].setFont(new Font("Poppins", Font.BOLD, 32));
            botoes[i].setFocusPainted(false);
            botoes[i].addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Quando clica, manda o comando via TCP ex: MOVE;5
                    out.println("MOVE;" + posicao);
                }
            });
            painelTabuleiro.add(botoes[i]);
        }
        add(painelTabuleiro, BorderLayout.CENTER);
    }

    private void conectarAoServidor() {
        try {
            // Conecta ao localhost na mesma porta do servidor
            socket = new Socket("10.130.154.21", 8081);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

            // Inicia uma thread em background para receber as atualizações do servidor
            new Thread(new Runnable() {
                @Override
                public void run() {
                    escutarServidor();
                }
            }).start();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Não foi possível conectar ao servidor.", "Erro", JOptionPane.ERROR_MESSAGE);
            System.exit(0);
        }
    }

    private void escutarServidor() {
        try {
            String linha;
            while ((linha = in.readLine()) != null) {
                String[] partes = linha.split(";");
                String comando = partes[0];

                switch (comando) {
                    case "WELCOME":
                        meuSimbolo = partes[1].charAt(0);
                        setTitle("Jogo da Velha - Jogador " + meuSimbolo);
                        lblPlacar.setText("Aguardando oponente...");
                        break;

                    case "START":
                        lblPlacar.setText("Jogo iniciado! Você é o jogador: " + meuSimbolo);
                        break;

                    case "TURN":
                        vezAtual = partes[1].charAt(0);
                        if (vezAtual == meuSimbolo) {
                            lblPlacar.setText("Sua vez de jogar! (" + meuSimbolo + ")");
                        } else {
                            lblPlacar.setText("Vez do jogador " + vezAtual + "...");
                        }
                        break;

                    case "BOARD":
                        String[] valores = partes[1].split(",");
                        for (int i = 0; i < 9; i++) {
                            String val = valores[i];
                            // Se for número, deixa em branco como no seu HTML original
                            if (!val.equals("X") && !val.equals("O")) {
                                botoes[i].setText("");
                            } else {
                                botoes[i].setText(val);
                            }
                        }
                        break;

                    case "ERROR":
                        JOptionPane.showMessageDialog(this, partes[1], "Aviso", JOptionPane.WARNING_MESSAGE);
                        break;

                    case "OVER":
                        String subComando = partes[1];
                        if (subComando.equals("WIN")) {
                            char vencedor = partes[2].charAt(0);
                            JOptionPane.showMessageDialog(this, "Vitória do " + vencedor + "!");
                        } else if (subComando.equals("DRAW")) {
                            JOptionPane.showMessageDialog(this, "Deu Velha!");
                        } else if (subComando.equals("OPPONENT_DISCONNECTED")) {
                            JOptionPane.showMessageDialog(this, "O oponente desconectou. O jogo terminou.");
                        }
                        System.exit(0);
                        break;
                }
            }
        } catch (Exception e) {
            System.out.println("Conexão perdida com o servidor.");
        }
    }

    public static void main(String[] args) {
        // Garante a execução segura da interface gráfica do Swing
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new ClienteJogo().setVisible(true);
            }
        });
    }
}